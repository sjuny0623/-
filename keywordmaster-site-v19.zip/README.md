# 키워드마스터 웹사이트 — 시안19

## v19 변경 (상담 신청 접수)
- 신청서 → 신청 접수용 메일 주소 으로 메일 전달 (Web3Forms). 받는 주소는 접근 키에 묶여 페이지 소스에 드러나지 않음
- [입력 필요] https://web3forms.com 에서 신청 접수용 메일 주소 으로 Access Key 발급 → js/main.js 맨 위 WEB3FORMS_KEY 에 입력
  (키를 넣기 전에는 신청 시 "온라인 접수가 아직 준비 중입니다." 안내)
- 메일 제목: [키워드마스터 A/B/C등급] 무료 상담 신청 — 회사명 / 본문: 한글 항목 / 답장 → 신청자

Vanilla HTML/CSS/JS · 외부 라이브러리 없음 · Pretendard 웹폰트(CDN)
컬러: Ink #0A1024 · Deep #121A33 · Stone #EDEEEA · Master Blue #2340E0 · Ice #A9BBFF

## 섹션
01 Hero(헤드라인 + 신뢰 숫자) · 02 Problem · 03 Services · 04 How(여정 + 월간 리포트)
05 Work · 06 Start · 07 FAQ · 08 Contact(2단계 신청서) · Footer
+ 모바일 하단 고정 CTA

## 공개 전 체크리스트
[ ] js/main.js  WEB3FORMS_KEY 입력 (Web3Forms → 신청 접수용 메일 주소) / [ ] CONTACT_EMAIL(전송 실패 시 안내할 주소) 설정
[ ] privacy.html  파란 글씨 항목(보유 기간, 수탁자, 책임자, 시행일) 입력 + 법률 검토
[ ] 푸터 대표 이메일: index.html 주석 해제
[ ] og:image, canonical, og:url 을 실제 도메인 절대 주소로 교체 (images/og.png 준비됨)
[ ] sitemap.xml · robots.txt 도메인 교체
[ ] 계약서 반영 후 게시: 약정 없이 1개월 단위 · 계정과 데이터 광고주 소유 · 첫 달 세팅
[ ] 사례 PROBLEM / RESULT 문구 검수, 교육·리조트 사례 자료 보완
[ ] 작업물 이미지 게재 동의(법무법인, 클리닉)
[ ] 리드 등급 기준(js/main.js LEAD_RULES) 실제 계약 데이터 보고 조정
[ ] 실제 도메인에서 Lighthouse 측정 (목표: 성능 90+, 접근성 95+)
