# 키워드마스터 웹사이트 — 시안8 (신청서 개선판)

## v8 변경 (신청서)
- '맡긴 업체 수' 질문 삭제 (화면 · 검증 · 전송 데이터 · 개인정보처리방침). 여러 업체 사용 여부는 Problem 자가 점검의 '업체 분산'으로 계속 전달됨
- 1단계 순서: 필요한 마케팅 영역 → 시작 희망 시점 → 문의 수 확인 → 월 광고비 (헤드라인 "무엇부터 시작할까요?"에 첫 질문으로 답하고, 가장 민감한 광고비는 마지막)
- '닮고 싶거나 앞서고 싶은 업체': "상담 전에 비교해 보고 오겠습니다" → "적어 주시면, 상담 때 그 업체와의 차이부터 짚어 드립니다." 옅은 파란 판으로 구분, 입력하면 "비교 대상 ‘○○’ · 상담 때 차이부터 짚어 드립니다."로 바뀜
- Problem 섹션에서 고른 고민을 '기타 상담 내용' 위에 "함께 전달됩니다"로 표시
- 리드 점수: 업체 수(최대 1점) 대신 참고 업체 입력 시 +1 (총점 범위 동일, 등급 기준 그대로)


Vanilla HTML/CSS/JS · 외부 라이브러리 없음 · Pretendard 웹폰트(CDN)
컬러: Ink #0A1024 · Deep #121A33 · Stone #EDEEEA · Master Blue #2340E0 · Ice #A9BBFF

## 섹션
01 Hero · 02 Trust · 03 Problem · 04 Services(5개 영역 18가지 → KEYWORDMASTER)
05 Journey(FIND → CHOOSE → CONTACT → MEASURE ↺) · 06 Report · 07 Work · 08 Start
띠(클릭이 아니라, 문의로) · 09 FAQ · 10 Contact(2단계 신청서) · Footer
+ 모바일 하단 고정 CTA

## 공개 전 체크리스트
[ ] js/main.js  FORM_ENDPOINT, CONTACT_EMAIL 설정 (설정 전에는 모든 신청이 실패로 안내됨)
[ ] privacy.html  파란 글씨 항목(보유 기간, 수탁자, 책임자, 시행일) 입력 + 법률 검토
[ ] 푸터 대표 이메일: index.html 주석 해제
[ ] og:image, canonical, og:url 을 실제 도메인 절대 주소로 교체 (images/og.png 준비됨)
[ ] sitemap.xml · robots.txt 도메인 교체
[ ] 계약서 반영 후 게시: 약정 없이 1개월 단위 · 계정과 데이터 광고주 소유 · 첫 달 세팅
[ ] 사례 PROBLEM / RESULT 문구 검수, 교육·리조트 사례 자료 보완
[ ] 작업물 이미지 게재 동의(법무법인, 클리닉)
[ ] 리드 등급 기준(js/main.js LEAD_RULES) 실제 계약 데이터 보고 조정
[ ] 실제 도메인에서 Lighthouse 측정 (목표: 성능 90+, 접근성 95+)
