# 키워드마스터 웹사이트 — 시안7 (종합 개선판)

Vanilla HTML/CSS/JS · 외부 라이브러리 없음 · Pretendard 웹폰트(CDN)
컬러: Ink #0A1024 · Deep #121A33 · Stone #EDEEEA · Master Blue #2340E0 · Ice #A9BBFF

## 섹션
01 Hero · 02 Trust · 03 Problem · 04 Services(5개 영역 18가지 → KEYWORDMASTER)
05 Journey(FIND → CHOOSE → CONTACT → MEASURE ↺) · 06 Report · 07 Work · 08 Start
띠(클릭이 아니라, 문의로) · 09 FAQ · 10 Contact(2단계 신청서) · Footer
+ 모바일 하단 고정 CTA

## 공개 전 체크리스트
[ ] js/main.js  FORM_ENDPOINT, CONTACT_EMAIL 설정 (설정 전에는 모든 신청이 실패로 안내됨)
[ ] privacy.html  파란 글씨 항목(보유 기간, 수탁자, 책임자, 시행일) 입력 + 법률 검토
[ ] 푸터 대표 이메일: index.html 주석 해제
[ ] og:image, canonical, og:url 을 실제 도메인 절대 주소로 교체 (images/og.png 준비됨)
[ ] sitemap.xml · robots.txt 도메인 교체
[ ] 계약서 반영 후 게시: 약정 없이 1개월 단위 · 계정과 데이터 광고주 소유 · 첫 달 세팅
[ ] 사례 PROBLEM / RESULT 문구 검수, 교육·리조트 사례 자료 보완
[ ] 작업물 이미지 게재 동의(법무법인, 클리닉)
[ ] 리드 등급 기준(js/main.js LEAD_RULES) 실제 계약 데이터 보고 조정
[ ] 실제 도메인에서 Lighthouse 측정 (목표: 성능 90+, 접근성 95+)
