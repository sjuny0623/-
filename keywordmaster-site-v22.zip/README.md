# 키워드마스터 웹사이트 — 시안22

## v22 변경 (Services 카드)
- 01~09 번호 삭제 → [아이콘] 서비스 이름 영문 꼬리표 한 줄 (SEO → 검색엔진 최적화 · SEO, GEO → AI 검색 최적화 · GEO)
- 질문 17px · 굵게, 답은 한 단계 작게 → 이름 다음으로 대표님 질문이 먼저 읽힘
- YES 는 카드 윗변에서 내려오는 탭, 마우스를 올리면 아이콘 칸이 파랗게
- 마지막 파란 카드: '10' → '마지막 질문'

## v21 변경 (Services 카드)
- 기본: 섹션보다 한 단계 밝은 면 + 위쪽 옅은 빛 + 또렷한 테두리 → 배경에서 카드가 떠 보임
- 마우스(모바일은 화면 가운데 카드): 4px 떠오름 · 파란 빛 그림자 · 윗변 파란 선 · YES

## v20 변경
- Web3Forms Access Key 입력 완료 → 실제 도메인에서 신청하면 접수용 메일 주소로 도착

## v19 변경 (상담 신청 접수)
- 신청서 → 신청 접수용 메일 주소 으로 메일 전달 (Web3Forms). 받는 주소는 접근 키에 묶여 페이지 소스에 드러나지 않음
- Access Key 는 js/main.js 맨 위 WEB3FORMS_KEY (키가 비어 있으면 신청 시 "온라인 접수가 아직 준비 중입니다." 안내)
- 메일 제목: [키워드마스터 A/B/C등급] 무료 상담 신청 — 회사명 / 본문: 한글 항목 / 답장 → 신청자

Vanilla HTML/CSS/JS · 외부 라이브러리 없음 · Pretendard 웹폰트(CDN)
컬러: Ink #0A1024 · Deep #121A33 · Stone #EDEEEA · Master Blue #2340E0 · Ice #A9BBFF

## 섹션
01 Hero(헤드라인 + 신뢰 숫자) · 02 Problem · 03 Services · 04 How(여정 + 월간 리포트)
05 Work · 06 Start · 07 FAQ · 08 Contact(2단계 신청서) · Footer
+ 모바일 하단 고정 CTA

## 공개 전 체크리스트
[x] js/main.js  WEB3FORMS_KEY 입력 완료 / [ ] 실제 도메인에서 테스트 신청 1건 → 메일 도착 확인 / [ ] CONTACT_EMAIL(전송 실패 시 안내할 주소) 설정
[ ] privacy.html  파란 글씨 항목(보유 기간, 수탁자, 책임자, 시행일) 입력 + 법률 검토
[ ] 푸터 대표 이메일: index.html 주석 해제
[ ] og:image, canonical, og:url 을 실제 도메인 절대 주소로 교체 (images/og.png 준비됨)
[ ] sitemap.xml · robots.txt 도메인 교체
[ ] 계약서 반영 후 게시: 약정 없이 1개월 단위 · 계정과 데이터 광고주 소유 · 첫 달 세팅
[ ] 사례 PROBLEM / RESULT 문구 검수, 교육·리조트 사례 자료 보완
[ ] 작업물 이미지 게재 동의(법무법인, 클리닉)
[ ] 리드 등급 기준(js/main.js LEAD_RULES) 실제 계약 데이터 보고 조정
[ ] 실제 도메인에서 Lighthouse 측정 (목표: 성능 90+, 접근성 95+)
